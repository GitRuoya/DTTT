﻿//Not the economics kind.
using UnityEngine;

public class Utils {

	public static int roundBy50 (int value)
	{
		return value - (value % 50);
	}

}
